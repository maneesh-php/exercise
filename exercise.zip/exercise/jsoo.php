<?php
$servername = "localhost";
$username = "manesh";
$password = "manesh";
$db ="coding_test";
// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 


 $sql= "SELECT * FROM `tbl_json`";
 $result = $conn->query($sql);

 if ($result->num_rows > 0) {
 	$row = $result->fetch_row();
 }
$keyTime = time();
if(count($row) > 0){
	$arr =json_decode($row[1],true);
	
	$arr [$keyTime] = rand(1,10000);
}else{
	$arr [$keyTime] = rand(1,10000);
}

 $pushArr =json_encode($arr);
 $sql1= "UPDATE `tbl_json` SET fingerprint = '$pushArr'  ";
 if ($conn->query($sql1) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}

 $sql= "SELECT * FROM `tbl_json`";
 $result = $conn->query($sql);

 if ($result->num_rows > 0) {
 	$row = $result->fetch_row();
 	$arr =json_decode($row[1],true);
 	echo '<pre>';print_r($arr);
 }

?>