<?php
class A{

	public function __construct()
	{
	    echo "i am constructor of class A"; 
	}
}

class B extends A
{
	
	public function __construct()
	{
		 parent::__construct();
		echo "i am constructor of class B"; 
	}
}


$obj= new B;

?>