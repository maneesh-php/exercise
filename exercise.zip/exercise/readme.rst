i have used codeigniter framework for the exercise

URL : http://localhost/exercise/

DATABASE NAME:  coding_test



Exercise 1. 

Q.1 & Q2 
Q1 :  URL : http://localhost/exercise

Exercise 3 

Q 1 & Q2 
Q1   URL : http://localhost/exercise/api/router

Q2 :  URL : http://localhost/exercise/welcome/testapi



And remaining answers are in 


exercise/exercise2 folder
