<?php


class Test{
	private static $count =0;
	public  function __construct(){
	  	self::$count++;
	}

	public function getCount(){
		return self::$count;
	}
}

$obj =new Test;
$obj =new Test;
$obj =new Test;
echo Test::getCount();
//echo Test::$count;
?>