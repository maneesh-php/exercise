<?php
//Execute below commands in your server //
// sudo apt-get install libssh2-php
//sudo service apache2 restart


//OR download http://phpseclib.sourceforge.net/

include('Net/SSH2.php');

$ssh = new Net_SSH2('www.domain.tld');
if (!$ssh->login('username', 'password')) {
    exit('Login Failed');
}

echo $ssh->exec('pwd');
echo $ssh->exec('ls -la');
?>
