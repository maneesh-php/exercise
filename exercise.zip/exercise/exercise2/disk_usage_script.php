<?php
float disk_total_space ( string $directory );


?>

